package com.scc.workoutapp.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.scc.workoutapp.R
import com.scc.workoutapp.database.AppDatabase
import com.scc.workoutapp.databinding.ActivityMainBinding
import com.scc.workoutapp.fragment.AddActivityFragment
import com.scc.workoutapp.fragment.ListFragment
import com.scc.workoutapp.model.WorkoutActivity

class MainActivity : AppCompatActivity() {

    private var binding: ActivityMainBinding? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        /* List fragment for showing list of activity */
        changeFragment(ListFragment(), "list")

//        val db = AppDatabase.getDatabase(this).databaseDao()
//
//        val activity = WorkoutActivity()

//        binding?.ivAdd?.setOnClickListener { changeFragment(AddActivityFragment(), "add_activity") }

    }

    /**
     * Used for change fragment
     */
    private fun changeFragment(fragment: Fragment, tag: String) {
        supportFragmentManager
            .beginTransaction()
            .add(fragment, tag)
            .replace(R.id.frameLayout, fragment)
            .addToBackStack(null)
            .commit()
    }

    override fun onDestroy() {
        super.onDestroy()
        //set null to avoid memory leak
        binding = null;
    }
}