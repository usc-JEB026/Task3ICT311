package com.scc.workoutapp.model

import android.os.Parcelable
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.parcelize.Parcelize

@Parcelize
@Entity(tableName = "tbl_activity")
data class WorkoutActivity(

    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "_id")
    val id: Long? = null,

    @ColumnInfo(name = "title")
    var title: String? = null,

    @ColumnInfo(name = "date")
    var date: Long? = null,

    @ColumnInfo(name = "place")
    var place: String? = null,

    @ColumnInfo(name = "start_time")
    var startTime: Long? = null,

    @ColumnInfo(name = "end_time")
    var endTime: Long? = null,

    @ColumnInfo(name = "type")
    var type: String? = null,
): Parcelable
