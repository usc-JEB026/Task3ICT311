package com.scc.workoutapp.fragment

import android.app.TimePickerDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.scc.workoutapp.database.AppDatabase
import com.scc.workoutapp.database.DatabaseDao
import com.scc.workoutapp.databinding.FragmentAddActivityBinding
import com.scc.workoutapp.model.WorkoutActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import java.util.Calendar.HOUR_OF_DAY
import java.util.Calendar.MINUTE


class AddActivityFragment : Fragment() {

    private var binding: FragmentAddActivityBinding? = null
    private lateinit var db: DatabaseDao
    private var workoutActivity: WorkoutActivity? = null
    private val startCal = Calendar.getInstance()
    private val endCal = Calendar.getInstance()
    private val date = Calendar.getInstance()
    private val dateFormat = SimpleDateFormat("dd MMMM yyyy")
    private val timeFormat = SimpleDateFormat("hh:mm a")

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        db = AppDatabase.getDatabase(requireContext()).databaseDao()
        binding = FragmentAddActivityBinding.inflate(inflater)
        return binding?.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        try {
            workoutActivity = arguments?.getParcelable("data")!!

        } catch (e: Exception) {
        }

        binding?.let { ui ->
            ui.ivBack.setOnClickListener {
                requireActivity().supportFragmentManager.popBackStack()
            }

            workoutActivity?.let {

                startCal.timeInMillis = it.startTime!!
                endCal.timeInMillis = it.endTime!!

                ui.edtTitle.setText(it.title)
                ui.edtDate.setTime(it.date!!)
                ui.edtPlace.setText(it.place)
                ui.edtStartTime.setText(timeFormat.format(startCal.time))
                ui.edtEndTime.setText(timeFormat.format(endCal.time))

                ui.btnAdd.text = "Update"
            }


            val arr = arrayOf("Individual", "Group")

            val adapter = ArrayAdapter(
                requireContext(),
                android.R.layout.simple_spinner_item, arr
            )
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            ui.spnType.adapter = adapter

            ui.edtStartTime.setOnClickListener {
                if (workoutActivity == null)
                    startCal.timeInMillis = System.currentTimeMillis()

                TimePickerDialog(
                    requireContext(),
                    { p0, p1, p2 ->
                        val formater = SimpleDateFormat("hh:mm a")
                        startCal[HOUR_OF_DAY] = p1
                        startCal[MINUTE] = p2
                        ui.edtStartTime.setText(formater.format(startCal.time))

                    }, startCal.get(Calendar.HOUR_OF_DAY), startCal.get(MINUTE), false
                ).show()
            }

            ui.edtEndTime.setOnClickListener {
                if (workoutActivity == null)
                    endCal.timeInMillis = System.currentTimeMillis()

                TimePickerDialog(
                    requireContext(),
                    { p0, p1, p2 ->
                        val formater = SimpleDateFormat("hh:mm a")
                        endCal[HOUR_OF_DAY] = p1
                        endCal[MINUTE] = p2
                        ui.edtEndTime.setText(formater.format(endCal.time))

                    }, endCal.get(Calendar.HOUR_OF_DAY), endCal.get(MINUTE), false
                ).show()
            }

            ui.btnAdd.setOnClickListener {
                if (workoutActivity == null) {
                    if (isValid()) {
                        val activity = WorkoutActivity()
                        activity.title = ui.edtTitle.text.toString()
                        activity.date = ui.edtDate.dateInMillis
                        activity.place = ui.edtPlace.text.toString()
                        activity.type = ui.spnType.selectedItem.toString()
                        activity.startTime = startCal.timeInMillis
                        activity.endTime = endCal.timeInMillis
                        addActivity(activity)
                        requireActivity().supportFragmentManager.popBackStack()
                        Toast.makeText(requireContext(), "Added Successfully", Toast.LENGTH_SHORT)
                            .show()
                    }
                } else {
                    //Update
                    workoutActivity!!.title = ui.edtTitle.text.toString()
                    workoutActivity!!.date = ui.edtDate.dateInMillis
                    workoutActivity!!.place = ui.edtPlace.text.toString()
                    workoutActivity!!.type = ui.spnType.selectedItem.toString()
                    workoutActivity!!.startTime = startCal.timeInMillis
                    workoutActivity!!.endTime = endCal.timeInMillis
                    updateActivity(workoutActivity!!)
                    requireActivity().supportFragmentManager.popBackStack()
                    Toast.makeText(requireContext(), "Updated Successfully", Toast.LENGTH_SHORT)
                        .show()
                }
            }

        }
    }

    private fun updateActivity(activity: WorkoutActivity) {
        CoroutineScope(Dispatchers.IO).launch {
            db.updateActivity(activity)
        }

    }

    private fun isValid(): Boolean {
        if (binding?.edtTitle?.text.toString().isEmpty()) {
            Toast.makeText(requireContext(), "Enter Title", Toast.LENGTH_SHORT).show()
            return false
        }

        if (binding?.edtDate?.text.toString().isEmpty()) {
            Toast.makeText(requireContext(), "Enter Date", Toast.LENGTH_SHORT).show()
            return false
        }
        if (binding?.edtPlace?.text.toString().isEmpty()) {
            Toast.makeText(requireContext(), "Enter Place", Toast.LENGTH_SHORT).show()
            return false
        }

        if (binding?.edtStartTime?.text.toString().isEmpty()) {
            Toast.makeText(requireContext(), "Enter Start Time", Toast.LENGTH_SHORT).show()
            return false
        }

        if (binding?.edtEndTime?.text.toString().isEmpty()) {
            Toast.makeText(requireContext(), "Enter End Time", Toast.LENGTH_SHORT).show()
            return false
        }

        return true
    }

    /* Add Activity to Database */
    private fun addActivity(activity: WorkoutActivity) {
        CoroutineScope(Dispatchers.IO).launch {
            db.insertActivity(activity)
        }

    }

    override fun onDestroy() {
        super.onDestroy()
        binding = null
    }
}