package com.scc.workoutapp.utils

import android.app.Activity
import androidx.appcompat.widget.AppCompatEditText
import android.app.DatePickerDialog.OnDateSetListener
import com.scc.workoutapp.utils.DatePickerEditText.OnDateSet
import android.text.InputType
import android.app.DatePickerDialog
import android.content.Context
import android.util.AttributeSet
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.DatePicker
import java.text.SimpleDateFormat
import java.util.*

class DatePickerEditText : AppCompatEditText, View.OnClickListener, OnDateSetListener {
    private var dateTimeFormat = "dd MMMM yyyy"
    private var simpleDateFormat: SimpleDateFormat? = null
    private var mCalendar: Calendar? = null
    private var minDate: Long = 0
    private var onDateSet: OnDateSet? = null

    constructor(context: Context?) : super(context!!) {
        init()
    }

    constructor(context: Context?, attrs: AttributeSet?) : super(
        context!!, attrs
    ) {
        init()
    }

    constructor(context: Context?, attrs: AttributeSet?, defStyleAttr: Int) : super(
        context!!, attrs, defStyleAttr
    ) {
        init()
    }

    private fun init() {
        simpleDateFormat = SimpleDateFormat(dateTimeFormat, Locale.US)
        mCalendar = Calendar.getInstance()
        setOnClickListener(this)

        isFocusable = false
        isLongClickable = false
        inputType = InputType.TYPE_NULL

    }

    val date: Date
        get() = mCalendar!!.time
    val dateInMillis: Long
        get() = mCalendar!!.timeInMillis

    fun setDateTimeFormat(format: String) {
        dateTimeFormat = format
        simpleDateFormat = SimpleDateFormat(dateTimeFormat, Locale.US)
    }

    val dayOfMonth: Int
        get() = mCalendar!![Calendar.DAY_OF_MONTH]
    val month: Int
        get() = mCalendar!![Calendar.MONTH]
    val year: Int
        get() = mCalendar!![Calendar.YEAR]

    fun setTime(millis: Long) {
        mCalendar!!.timeInMillis = millis
        setText(simpleDateFormat!!.format(mCalendar!!.time))
    }

    fun setDateSetListener(onDateSet: OnDateSet?) {
        this.onDateSet = onDateSet
    }

    override fun onClick(v: View) {

        val imm = context.getSystemService(Activity.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(v.windowToken, 0)
        v.clearFocus()

        val dialog = DatePickerDialog(
            v.context,
            this,
            mCalendar!![Calendar.YEAR],
            mCalendar!![Calendar.MONTH],
            mCalendar!![Calendar.DAY_OF_MONTH]
        )
        if (minDate > 0) dialog.datePicker.minDate = minDate
        dialog.show()
    }

    override fun onDateSet(view: DatePicker, year: Int, month: Int, dayOfMonth: Int) {
        mCalendar!![Calendar.YEAR] = year
        mCalendar!![Calendar.MONTH] = month
        mCalendar!![Calendar.DAY_OF_MONTH] = dayOfMonth
        setText(simpleDateFormat!!.format(mCalendar!!.time))
        if (onDateSet != null) onDateSet!!.selectedDate(mCalendar!!.time)
    }

    fun setMinDate(date: Long) {
        minDate = date
    }

    interface OnDateSet {
        fun selectedDate(date: Date?)
    }
}