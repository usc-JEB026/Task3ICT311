package com.scc.workoutapp.fragment

import android.app.AlertDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.View.GONE
import android.view.View.VISIBLE
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.scc.workoutapp.R
import com.scc.workoutapp.adapter.ActivityAdapter
import com.scc.workoutapp.database.AppDatabase
import com.scc.workoutapp.database.DatabaseDao
import com.scc.workoutapp.databinding.FragmentListBinding
import com.scc.workoutapp.model.WorkoutActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch


class ListFragment : Fragment(), ActivityAdapter.OnClickListener {

    private var binding: FragmentListBinding? = null
    private lateinit var db: DatabaseDao
    private lateinit var adapter: ActivityAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = AppDatabase.getDatabase(requireContext()).databaseDao()
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentListBinding.inflate(inflater)
        return binding?.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding?.let {
            //Attach Adapter to Recyclerview
            it.rvActivity.layoutManager = LinearLayoutManager(requireContext())
            adapter = ActivityAdapter(this)
            it.rvActivity.adapter = adapter
            it.ivAdd.setOnClickListener {
                changeFragment(AddActivityFragment(), "add_activity")
            }
        }

    }

    override fun onResume() {
        super.onResume()

        CoroutineScope(Dispatchers.IO)
            .launch {
                val list = db.getAllActivity()

                if (list.isEmpty()) {
                    binding?.tvNoData?.visibility = VISIBLE
                    binding?.tvNoData2?.visibility = VISIBLE
                } else {
                    binding?.tvNoData?.visibility = GONE
                    binding?.tvNoData2?.visibility = GONE
                }
                adapter.addData(list)
            }

    }

    override fun onDestroy() {
        super.onDestroy()
        binding = null
    }

    /**
     * Used for change fragment
     */
    private fun changeFragment(fragment: Fragment, tag: String) {
        requireActivity().supportFragmentManager
            .beginTransaction()
            .add(fragment, tag)
            .replace(R.id.frameLayout, fragment)
            .addToBackStack(null)
            .commit()
    }

    override fun onClick(activity: WorkoutActivity, position: Int) {
        val arr = arrayOf("Edit", "Delete")
        AlertDialog.Builder(requireContext())
            .setTitle("Select Option")
            .setItems(arr) { p0, p1 ->
                if (p1 == 0) {
                    val bundle = Bundle()
                    bundle.putParcelable("data", activity)
                    val fragment = AddActivityFragment()
                    fragment.arguments = bundle
                    changeFragment(fragment, "add_activity")
                } else {
                    AlertDialog.Builder(requireContext())
                        .setTitle("Delete")
                        .setMessage("Are you sure you want to delete?")
                        .setPositiveButton(
                            "Yes"
                        ) { p0, p1 ->
                            adapter.deleteItem(position)
                            CoroutineScope(Dispatchers.IO).launch {
                                db.deleteActivity(activity)
                            }
                            if (adapter.itemCount <= 0) {
                                binding?.tvNoData?.visibility = VISIBLE
                                binding?.tvNoData2?.visibility = VISIBLE
                            } else {
                                binding?.tvNoData?.visibility = GONE
                                binding?.tvNoData2?.visibility = GONE
                            }

                        }
                        .setNegativeButton(
                            "No"
                        ) { p0, p1 ->

                        }
                        .show()
                }
            }
            .show()

    }
}