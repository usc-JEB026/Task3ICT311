package com.scc.workoutapp.adapter

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.scc.workoutapp.R
import com.scc.workoutapp.model.WorkoutActivity
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList

class ActivityAdapter(
    private val onClickListener: OnClickListener
) :
    RecyclerView.Adapter<ActivityAdapter.Viewholder>() {

    private var list: ArrayList<WorkoutActivity>

    init {
        list = ArrayList()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ActivityAdapter.Viewholder {
        return Viewholder(
            LayoutInflater.from(parent.context).inflate(R.layout.rv_list_item_layout, parent, false)
        )
    }

    override fun onBindViewHolder(holder: ActivityAdapter.Viewholder, position: Int) {
        holder.bindData(list[position])
    }

    override fun getItemCount(): Int {
        return list.size
    }

    fun addData(list: List<WorkoutActivity>) {
        this.list = list as ArrayList<WorkoutActivity>
        notifyDataSetChanged()
    }

    fun deleteItem(position: Int) {
        list.removeAt(position)
        notifyItemRemoved(position)
    }

    interface OnClickListener {
        fun onClick(activity: WorkoutActivity, position: Int)
    }

    inner class Viewholder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        private val title = itemView.findViewById<TextView>(R.id.tvTitle)
        private val tvDate = itemView.findViewById<TextView>(R.id.tvDate)
        private val tvPlace = itemView.findViewById<TextView>(R.id.tvPlace)
        private val tvType = itemView.findViewById<TextView>(R.id.tvType)
        private val tvTime = itemView.findViewById<TextView>(R.id.tvTime)

        private var dateFormat = SimpleDateFormat("dd MMMM yyyy")
        private var timeFormat = SimpleDateFormat("hh:mm a")

        init {
            itemView.setOnClickListener {
                onClickListener.onClick(list[adapterPosition], adapterPosition)
            }

        }

        @SuppressLint("SetTextI18n")
        fun bindData(activity: WorkoutActivity) {
            val cal = Calendar.getInstance()
            cal.timeInMillis = activity.date!!

            val start = Calendar.getInstance()
            start.timeInMillis = activity.startTime!!

            val end = Calendar.getInstance()
            end.timeInMillis = activity.endTime!!

            title.text = activity.title
            tvDate.text = dateFormat.format(cal.time)
            tvPlace.text = activity.place
            tvType.text = activity.type
            tvTime.text = "${timeFormat.format(start.time)} - ${timeFormat.format(end.time)}"

        }

    }
}