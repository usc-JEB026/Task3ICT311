package com.scc.workoutapp.database

import androidx.room.*
import com.scc.workoutapp.model.WorkoutActivity

@Dao
interface DatabaseDao {

    @Insert
    suspend fun insertActivity(activity: WorkoutActivity)

    @Query("SELECT * FROM tbl_activity ORDER BY _id DESC")
    suspend fun getAllActivity(): List<WorkoutActivity>

    @Delete
    suspend fun deleteActivity(activity: WorkoutActivity)

    @Update
    suspend fun updateActivity(activity: WorkoutActivity)
}